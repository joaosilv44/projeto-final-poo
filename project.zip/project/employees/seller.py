
from .employee import Employee
    
class Seller(Employee): 
    def __init__(self, name, shift, cpf, salary,id_employee,departament,status_employee,admission_date,contract_type,position,meta_monthly, overtime, hours_worked, commision_percentual):
        
        super().__init__(name, shift, cpf, salary, id_employee,
                         departament, status_employee, admission_date,
                         contract_type, position, meta_monthly, overtime, 
                         hours_worked)
        
        self.__costumers_served = []
        self.__pallets_sold = 0
        self.__quantity_invites = []
        self.__comission_percentual = commision_percentual
        self.__sales_made = []
        
    @property
    def meta_monthly(self):
        return super().meta_monthly
    
    @meta_monthly.setter
    def meta_monthly(self, value):
        if value <= 0:
            raise ValueError("A meta deve ser maior do que zero")
        self._Employee__meta_monthly = value
        
    @property
    def pallets_sold(self):
        return self.__pallets_sold
        
    def attend_costumer(self, customer):
        self.__costumers_served.append(customer)
        
    def make_sale(self, costumer, product, quantity):
        sale = {
            "costumer":costumer,
            "product":product,
            "quantity":quantity
        }
        self.__sales_made.append(sale)
        
    def add_pallets_sold(self, quantity):
        if quantity <= 0:
            raise ValueError("A quantidade é inválida")
        self.__pallets_sold += quantity

    def follow_costumer(self, client):
        return f"Acompanhamento realizado com o cliente {client}"
    
    def apply_costumer_benefi(self, client):
        return f"O benefício de fidelidade foi aplicado ao cliente {client}"
    
    def negotiate_price(self, discount):
        if discount < 0 or discount > 0.15:
            raise ValueError("O desconto deve encontrar-se entre 0% e 15%")
        return f"Desconto de {discount * 100:.0f}% aprovado!"
    
    def verify_meta_monthly(self):
        return self.meta_monthly <= self.__pallets_sold
    
    def calculate_comissions(self):
        return self.__pallets_sold * self.__comission_percentual
    
    def register_service(self, client):
        self.__quantity_invites.append(client)
        
    def request_evaluation(self, note):
        if note < 1 or note > 5:
            raise ValueError(" A nota se encontra em uma escala de 1 a 5.")
        
    def respond_to_complaint(self, client):
        return f"Reclamação do cliente {client} foi respondida"
    
    def sumary_sales(self):
        """
        Função: Retornar um sumário de vendas com o número de clientes atendidos,
                número de vendas realizadas, pallets vendidos e o calcular a comissão
                acerca das ações do funcionário.
        """
        return {
        "clientes_atendidos": len(self.__costumers_served),
        "vendas_realizadas": len(self.__sales_made),
        "paletes_vendidos": self.__pallets_sold,
        "comissao": self.calculate_comissions()
    }

#!ver isso ainda
    #def see_costumer_credit(self, client):
        #if client
